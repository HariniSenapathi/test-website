function buttonClicked(){
    alert("I'm clicked");
    }
   function buttonchangetextClicked(){
    document.getElementById('targetTag').innerHTML = "Javascript";
   } 
   